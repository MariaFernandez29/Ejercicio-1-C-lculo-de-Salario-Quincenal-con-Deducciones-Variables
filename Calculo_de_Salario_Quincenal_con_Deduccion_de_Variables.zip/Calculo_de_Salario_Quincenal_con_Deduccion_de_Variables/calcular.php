<?php
// Tarifas por hora (Bs.)
$tarifa_diurna = 675;
$tarifa_vespertina = 700;
$tarifa_nocturna = 956.23;

// Datos del formulario
$nombre = $_POST['nombre'];
$cedula = $_POST['cedula'];
$horas_diurnas = $_POST['horas_diurnas'];
$horas_vespertinas = $_POST['horas_vespertinas'];
$horas_nocturnas = $_POST['horas_nocturnas'];

// Sueldo bruto
$sueldo_bruto = ($horas_diurnas * $tarifa_diurna)
              + ($horas_vespertinas * $tarifa_vespertina)
              + ($horas_nocturnas * $tarifa_nocturna);

// Porcentajes según la escala salarial
if ($sueldo_bruto < 85000) {
    $porc_ahorro = 0.1;
    $porc_seguro = 0.15;
} elseif ($sueldo_bruto <= 150000) {
    $porc_ahorro = 0.15;
    $porc_seguro = 0.2;
} else {
    $porc_ahorro = 0.3;
    $porc_seguro = 0.25;
}

// Montos descontados
$ahorro = $sueldo_bruto * $porc_ahorro / 100;
$seguro = $sueldo_bruto * $porc_seguro / 100;
$sueldo_neto = $sueldo_bruto - $ahorro - $seguro;
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Resultado</title>
</head>
<body>
    <h1>Resultado del cálculo</h1>

    <h2>Datos del empleado</h2>
    <p>Nombre: <?php echo htmlspecialchars($nombre); ?></p>
    <p>Cédula: <?php echo htmlspecialchars($cedula); ?></p>

    <h2>Horas trabajadas</h2>
    <p>Diurnas: <?php echo $horas_diurnas; ?> h</p>
    <p>Vespertinas: <?php echo $horas_vespertinas; ?> h</p>
    <p>Nocturnas: <?php echo $horas_nocturnas; ?> h</p>

    <h2>Sueldo</h2>
    <p>Sueldo quincenal bruto: <?php echo number_format($sueldo_bruto, 2, ',', '.'); ?> Bs.</p>

    <h2>Deducciones</h2>
    <p>Ahorro Habitacional (<?php echo $porc_ahorro; ?>%): <?php echo number_format($ahorro, 2, ',', '.'); ?> Bs.</p>
    <p>Seguro Social (<?php echo $porc_seguro; ?>%): <?php echo number_format($seguro, 2, ',', '.'); ?> Bs.</p>

    <h2>Sueldo quincenal neto: <?php echo number_format($sueldo_neto, 2, ',', '.'); ?> Bs.</h2>

    <p><a href="index.html">Volver</a></p>
</body>
</html>
